<?php
// @formatter:off
/**
 * Plugin Name: DearFlip 3D FlipBook
 * Description: Create Realistic 3D Flip-books using jQuery
 *
 * Version: 1.6.10
 *
 * Text Domain: DFLIP
 * Author: DearHive
 * Author URI: https://dearhive.com/
 *
 */